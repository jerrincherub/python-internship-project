from flask import Flask,render_template,request
import mysql.connector
user_dict={'admin':'1234','useradmin':'5678'}
conn = mysql.connector.connect(host='localhost',user='root',password="",database='bms')
mycursor=conn.cursor()
#create a flask application
app = Flask(__name__)

#Define the route 

@app.route('/')
def hello():
    return render_template('home.html')
@app.route('/Aboutus')
def Aboutus():
    return render_template('About.html')
@app.route('/contactus')
def contactus():
    return render_template('Contact.html')
@app.route('/Login')
def Login():
    return render_template('Login1.html')
@app.route('/Register')
def Register():
    return render_template('Register.html')
@app.route('/viewdonor',methods=['POST'])
def viewdonor():
    uname=request.form['username']
    pword=request.form['password']
    if uname not in user_dict:
        return render_template('user.html')
    elif user_dict[uname]!=pword:
         return render_template('Login1.html')
    else:
       return render_template('viewdonor.html') 
@app.route('/view')
def view():
    query="SELECT * FROM DONOR"
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)
@app.route('/read',methods=['POST'])
def read():
    First_Name=request.form['First_Name']
    Last_Name=request.form['Last_Name']
    birthday=request.form['birthday']
    BloodGroup=request.form['BloodGroup']
    donationdate=request.form['donationdate']
    Email_Id=request.form['Email_Id']
    Mobile_Number=request.form['Mobile_Number']
    Address=request.form['Address']
    City=request.form['City']
    Pin_Code=request.form['Pin_Code']
    State=request.form['State']
    Country=request.form['Country']
    query="INSERT INTO DONOR(FIRSTNAME,LASTNAME,DATEOFBIRTH,BLOODGROUP,LASTDONATIONDATE,EMAIL,MOBILENUMBER,ADDRESS,CITY,PINCODE,STATE,COUNTRY) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    data=(First_Name,Last_Name,birthday,BloodGroup,donationdate,Email_Id,Mobile_Number,Address,City,Pin_Code,State,Country)
    mycursor.execute(query,data)
    conn.commit()
    return render_template('Login1.html')
@app.route('/search')
def searchpage():
    return render_template('search.html')
@app.route('/delete')
def deletepage():
    return render_template('deletedata.html')
@app.route('/searchresult',methods=['POST'])
def search():
    City=request.form['City']
    BloodGroup=request.form['BloodGroup']
    query="SELECT * FROM DONOR WHERE CITY=%s AND BLOODGROUP=%s"
    data=(City,BloodGroup)
    mycursor.execute(query,data)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)

@app.route('/deletedata',methods=['POST'])
def delete():
    Mobile_Number=request.form['Mobile_Number']
    Email_Id=request.form['Email_Id']
    query="DELETE FROM DONOR WHERE EMAIL=%s AND MOBILENUMBER=%s"
    data=(Email_Id,Mobile_Number)
    mycursor.execute(query,data)
    conn.commit()
   
    data=mycursor.fetchall()
    return render_template('viewdonor.html',sqldata=data)
@app.route('/Logout')
def Logout():
    return render_template('home.html')
@app.route('/update')
def update():
    return render_template('update.html')
     



   






    
#Run the flask app
if __name__=='__main__':
    app.run(port=5001,debug = True)