from flask import Flask,render_template,request
import mysql.connector
user_dict={'admin':'1234','user':'5678'}
conn = mysql.connector.connect(host='localhost',user='root',password="",database='vms')
mycursor=conn.cursor()
#create a flask application
app = Flask(__name__)

#Define the route 

@app.route('/')
def hello():
    return render_template('home.html')
@app.route('/products')
def products():
    return render_template('Products.html')
@app.route('/contactus')
def contactus():
    return render_template('Contact.html')
@app.route('/projects')
def projects():
    return render_template('Projects.html')
@app.route('/viewsupplier')
def viewsupplier():
    query="SELECT * FROM SUPPLIER"
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('viewsupplier.html',sqldata=data)
@app.route('/login')
def login():
    return render_template('Login.html')
@app.route('/supplier',methods=['POST'])
def supplier():
    uname=request.form['username']
    pword=request.form['password']
    if uname not in user_dict:
        return render_template('Login.html',msg='Invalid user')
    elif user_dict[uname]!=pword:
         return render_template('Login.html',msg='Invalid user')
    else:
        return render_template('supplier.html')
@app.route('/read',methods=['POST'])
def read():
    sname=request.form['sname']
    companyname=request.form['companyname']
    mobilenumber=request.form['mobilenumber']
    email=request.form['email']
    query="INSERT INTO SUPPLIER(NAME,COMPANYNAME,MOBILENUMBER,EMAIL) VALUES(%s,%s,%s,%s)"
    data=(sname,companyname,mobilenumber,email)
    mycursor.execute(query,data)
    conn.commit()
    return render_template('Projects.html')
    


#Run the flask app
if __name__=='__main__':
    app.run(port=5001,debug = True)