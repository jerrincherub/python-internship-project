from flask import Flask,render_template,request
user_dict={'admin':'1234','user':'5678'}
#create a flask application
app = Flask(__name__)

#Define the route 

@app.route('/')
def hello():
    return render_template('home.html')
@app.route('/contactus')
def contactus():
    return render_template('Contact.html')
@app.route('/login')
def login():
    uname=request.form['username']
    pword=request.form['password']
    if uname not in user_dict:
        return render_template('Login1.html',msg='Invalid user')
    elif user_dict[uname]!=pword:
         return render_template('Login1.html',msg='Invalid user')
    else:
        return render_template('home.html')
#Run the flask app
if __name__=='__main__':
    app.run(port=5001,debug = True)